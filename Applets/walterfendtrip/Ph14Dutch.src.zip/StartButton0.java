/*    */ import java.awt.Color;
/*    */ import javax.swing.JButton;
/*    */ 
/*    */ public final class StartButton0 extends JButton
/*    */ {
/*    */   public StartButton0(String paramString)
/*    */   {
/* 16 */     setBackground(Color.yellow);
/* 17 */     setIcon(new PlayIcon()); setText(paramString);
/* 18 */     setIconTextGap(50);
/* 19 */     setFocusPainted(false);
/*    */   }
/*    */ }

/* Location:           C:\Users\PJay\Documents\PWS\walterfendtrip\ph14_jar\Ph14Dutch.jar
 * Qualified Name:     StartButton0
 * JD-Core Version:    0.6.0
 */